package Main;

import MVC.MVC;

public class Main {
    public static void main(String[] args) {
        MVC mvc = new MVC() ;
    }
    
}
